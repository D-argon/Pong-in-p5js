//variaveis bola
const X0bola = 300;
const Y0bola = 200;

let xBola = 300;
let yBola = 200;

let d = 20;
let r = d / 2 ;

//velocidade bola
let BvelocidadeX = 6;
let BvelocidadeY = BvelocidadeX;


//Bola
function Bola(){
  
  fill(51, 255, 0);
  square(xBola, yBola, d);  
}

function MovimentoB(){
  
  xBola += BvelocidadeX;
  yBola += BvelocidadeY;
}

function ColisaoB(){
  
  if (xBola + r > width || xBola - r < 0){
    BvelocidadeX *= -1;
  }
  if (yBola + r > height || yBola - r < 0){
    BvelocidadeY *= -1;
  }
}

//variaveis Parede Player/Robô
let xParedeP = 50;
let yParedeP = 165;

let xParedeR = 550;
let yParedeR = 165;
let PRvelocidadeY;

let hParede = 90;
let wParede = 15;

let collide = false;

//Parede
function Parede(x, y){
  
  rect(x, y, wParede, hParede);
  noStroke();
} 

function MovimentoPP(){
  
  if 
    (keyIsDown(UP_ARROW)) {
    yParedeP -= 4;
    }
  if 
    (keyIsDown(DOWN_ARROW)) {
    yParedeP += 4;
    }
  
  //Colisao ParedeBorda
  if(yParedeP < 0) {
    yParedeP += 4;
  }
  if(yParedeP > 310) {
    yParedeP -= 4;
  }
}

function Colisao(x, y){
  
  if (xBola < x + wParede && yBola < y + hParede  && yBola > y) {
    BvelocidadeX *= -1;
  }
}

function ColisaoBB(x, y){
  
  collide = collideRectCircle(x, y, wParede, hParede, xBola, yBola, r);
  
  if(collide) {
    BvelocidadeX *= -1;
    toque.play();
  }
  
  //Tentativa correcao bug colisao square topo/fundo Parede
  if (yBola === y + hParede && xBola === x + wParede) {
    yBola = 10;
  }
    
}

//ParedeR
function MovimentoPR() {
  PRvelocidadeY = yBola - yParedeR - wParede /2 -30;
  yParedeR += PRvelocidadeY;
}

//Placar
let PontosP = 0;
let PontosR = 0;

function Placar() {
  
  fill(0, 245, 51, 150);
  textSize(32);
  text(PontosP, 150, 100);
  text(PontosR, 450, 100);
}

function pontuador(){
  if (xBola < 10){
    PontosR += 1;
  }
  if(xBola > 590){
      PontosP += 1;
  }

}

//Variaveis Som
let comeco;
let toque;
let ponto; 

//Som

function preload(){
  comeco = loadSound('cPong-.mp3');

}

//Resetar
function resetar(){
  
  if(keyIsDown(82)){
    PontosP *= 0;
    PontosR *= 0;
    xBola = 300;
    yBola = 200;
  }
}

//LinhaBG
function Meio(){
    
  rect(300 + wParede/3, -1, 10, 402);
}  


//executar

function setup() {
  
  createCanvas(600, 400);
  noStroke();
  comeco.play();
}

function draw() {

  background(40, 40, 40);
  Meio();
  Bola();
  MovimentoB();
  ColisaoB();
  Parede(xParedeP, yParedeP);
  MovimentoPP();
  //Colisao(xParedeP, yParedeP);
  ColisaoBB(xParedeP, yParedeP);                  //Biblioteca!!
  Parede(xParedeR, yParedeR);
  MovimentoPR();
  //Colisao(xParedeR, yParedeP);
  ColisaoBB(xParedeR, yParedeR); 
  Placar();
  pontuador();
  resetar();

}
